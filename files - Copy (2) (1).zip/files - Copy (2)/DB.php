<?php
$con = mysqli_connect("localhost","root","","web");

// if($con)
// {
//     echo "yes";
// }
// else{
//     echo "No"; 
// }
?>