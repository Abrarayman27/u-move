<?php
	// I have to initialize the variables i am using in my code.
	require "DB.php";
	$Fname = null;	
	$Lname = null;	
	$phone = null;	
	$email = null;	
	$password = null; 	
	$CP = null;

	$Fname_error = null;  
	$email_error = null;  
	$Lname_error = null;  
	$phone_error = null;    
	$password_error = null; 
	$CP_error = null; 
	$success = null;

	// First of all i have to check for the incoming post request.
	if(isset($_POST['sign-up'])){
		// If there is a post request, i will store the Fname and password values to variables.
		$Fname = $_POST['Fname'];
		$Lname = $_POST['Lname'];
		$phone = $_POST['phone'];
		$email = $_POST['email'];
		$password = $_POST['password'];
		$CP = $_POST['CP'];

		// Next i will check for empty values so i have some kind of error to display.
		if(empty(trim($Fname))){
			// If there is an empty value i display an error message.
			$Fname_error = "First Name filed is Empty";
		}
		if(empty(trim($Lname))){
			// If there is an empty value i display an error message.
			$Lname_error = "Last Name filed is Empty";
		}
		if(empty(trim($phone))){
			// If there is an empty value i display an error message.
			$phone_error = "Phone filed is empty";
		}
		elseif(strlen($phone) !== 11){
			$phone_error="invalid Phone";
		}
		elseif(!preg_match("#[0-9]{11}#",$phone))
			{
				$phone_error="invalid Phone";
			}
		if(empty(trim($email))){
			// If there is an empty value i display an error message.
			$email_error = "email filed is empty";
		}
		else if(!preg_match("	/^\w+([\.-]?\w+)@\w+([\.-]?\w+)(\.\w{2,3})+$/",$email))
		{
			$email_error ="invalid Email";
		}
			// If the Fname has a value, then i move on to the password field.
		if(empty(trim($password))){
				$password_error = "Password filed is empty";
		}
		
		
			elseif (strlen($_POST["password"]) < '8') {
				$password_error ="Your Password Must Contain At Least 8 Characters!";
			}
			elseif(!preg_match("#[0-9]+#",$password)) {
				$password_error ="Your Password Must Contain At Least 1 Number!";
			}
			elseif(!preg_match("#[A-Z]+#",$password)) {
				$password_error ="Your Password Must Contain At Least 1 Capital Letter!";
			}
			elseif(!preg_match("#[a-z]+#",$password)) {
				$password_error ="Your Password Must Contain At Least 1 Lowercase Letter!";
			}
			if(empty(trim($CP))){
				$CP_error = "Confirm Password filed is empty";
		}
			else if($password != $CP){
				$CP_error="Passwords does not match";
			}
			else{
				$sql ="select * from signup where phone ='$phone'";
				$res = mysqli_query($con,$sql) or die(mysqli_error($con));
				if(mysqli_num_rows($res)>=1){
				 $phone_error="Phone already login";
				//  require " script.php";
				}
				else{
				// $success = "Thank you for your registration";
				mysqli_query($con,"insert into signup (firstname,lastname,phone,email,password) values('$Fname','$Lname', $phone ,'$email','$password')");
				// require "n.html";
				}
				
	}

}
