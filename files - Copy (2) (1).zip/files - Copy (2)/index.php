<?php require("script.php") ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<!-- Setting the pages character encoding -->
	<meta charset="UTF-8">
	
	<!-- The meta viewport will scale my content to any device width -->
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	 <!-- Link to my stylesheet -->
	 <link rel="stylesheet" href="s.css">
	 <?php
	 	if($Fname_error != null){
	 		?> <style>.Fname-error{display:block}</style> <?php
	 	}
	 	elseif($Lname_error != null){
	 		?> <style>.Lname-error{display:block}</style> <?php
	 	}
	 	elseif($phone_error != null){
	 		?> <style>.phone-error{display:block}</style> <?php
	 	}
	 	elseif($email_error != null){
	 		?> <style>.email-error{display:block}</style> <?php
	 	}
	 	elseif($password_error != null){
	 		?> <style>.password-error{display:block}</style> <?php
	 	}
	 	elseif($CP_error != null){
	 		?> <style>.CP-error{display:block}</style> <?php
	 	}
	 	elseif($success != null){
	 		?> <style>.success{display:block}</style> <?php
	 	}
	 ?> 

	<title>Displaying errors with PHP</title>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta2/css/all.min.css" integrity="sha512-YWzhKL2whUzgiheMoBFwW8CKV4qpHQAEuvilg9FAn5VJUDwKZZxkJNuGM4XkWuk94WCrrwslk8yWNGmY1EduTA==" crossorigin="anonymous" referrerpolicy="no-referrer" />

</head>
<body>
<div class="page">
	
	<!-- <h1>Displaying form errors with PHP</h1> -->

	<div class="sign_up">
        <div class="contner">
    <h1>Sign Up</h1>
    <form class="form" id="form" method="post" action="" autocomplete="off">
        <div class="form-control" id="F">
        <i class="fa-solid fa-user"></i></i>
        <input type="text" placeholder="First Name" class="FN" id="name1" name="Fname" value="<?php echo $Fname; ?>">
        <small class="error Fname-error">
		<?php echo $Fname_error; ?>
		</small></div>
        <div class="form-control" id="LD">
        <i class="fa-solid fa-user" ></i></i>
        <input type="text" placeholder="Last Name" class="LN" id="name2" name="Lname" value="<?php echo $Lname; ?>">
        <small id="LD" class="error Lname-error">
		<?php echo $Lname_error; ?>
		</small></div>

        <br>
        <div class="form-control">
        <i class="fa-solid fa-phone" ></i></i>
        <input type="text" placeholder="Phone Number" class="PH" id="phone" name="phone" value="<?php echo $phone; ?>">
        <small  class="error phone-error">
		<?php echo $phone_error; ?>
		</small></div>
        <br>
        <div class="form-control">
        <i class="fa-solid fa-envelope" ></i></i>
        <input type="text" placeholder="Email" class="E" id="email" name="email" value="<?php echo $email; ?>">
        <small  class="error email-error">
		<?php echo $email_error; ?>
		</small></div>
        <br>
        <div class="form-control">
        <i class="fa-solid fa-lock" ></i>
        <input type="password" placeholder="Password" name="password"  value="<?php echo $password; ?>" class="P">
        <img src="https://img.icons8.com/ios/50/000000/hide.png" width="20px" id="eye"/>
        <small  class="error password-error">
		<?php echo $password_error; ?>
		</small></div>
        <br>
        <div class="form-control">
        <i class="fa-solid fa-lock" ></i></i>
        <input type="password" placeholder="Confirm Password" class="CP" id="confirm" name="CP" value="<?php echo $CP; ?>">
        <img src="https://img.icons8.com/ios/50/000000/hide.png" width="20px" id="eyeI" onclick="closeEye()"/>
        <small  class="error CP-error">
		<?php echo $CP_error; ?>
		</small></div>
        <br>
    </div>
        <input type ="checkbox" required>By continuing you accept our <a id ="a" href="">Privacy Policy</a> and <a href="">Term of Use</a> 

        <br>
        <br>
        <input type="submit" id="btn" name="sign-up" value="Sign Up" class="button"> 
		<small class="success">
			<?php echo $success; ?>
		</small>
    </form>
</div>
</div>



</div>
</body>
</html>	